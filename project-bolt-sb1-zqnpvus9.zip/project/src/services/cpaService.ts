import { CPANetwork, CPAOffer } from '../types/cpa';
import { networks } from '../config/networks';
import { mockOffers } from '../data/mockOffers';
import { ApiClient } from './apiClient';

class CPAService {
  private networks: CPANetwork[];
  private apiClient: ApiClient;

  constructor() {
    this.networks = networks;
    this.apiClient = new ApiClient();
  }

  async fetchOffers(networkId: string): Promise<CPAOffer[]> {
    const network = this.networks.find(n => n.id === networkId);
    if (!network) {
      throw new Error(`Network ${networkId} not found`);
    }

    // If no API key is configured, return mock data
    if (!network.apiKey) {
      console.log(`No API key configured for ${network.name}, using mock data`);
      return mockOffers.filter(offer => offer.networkId === networkId);
    }

    try {
      const data = await this.apiClient.fetch(`${network.baseUrl}/offers`, {
        headers: {
          'X-API-KEY': network.apiKey,
        },
      });

      return this.normalizeOffers(data, network.id);
    } catch (error) {
      console.error(`Error fetching offers from ${network.name}:`, error);
      // Return mock data as fallback
      return mockOffers.filter(offer => offer.networkId === networkId);
    }
  }

  private normalizeOffers(data: any, networkId: string): CPAOffer[] {
    // Implement normalization logic based on network response format
    return mockOffers.filter(offer => offer.networkId === networkId);
  }
}

// Export a singleton instance
export const cpaService = new CPAService();