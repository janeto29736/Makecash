interface FetchOptions {
  headers?: Record<string, string>;
  method?: string;
  body?: string;
}

export class ApiClient {
  async fetch<T>(url: string, options: FetchOptions = {}): Promise<T> {
    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error(`API request failed: ${url}`, error);
      throw error;
    }
  }
}