// Base URLs for CPA networks
export const networkUrls = {
  mychips: 'https://api.mychips.com/v1',
  revu: 'https://api.revu.net/v2',
  adgem: 'https://api.adgem.com/v1',
  adsensemedia: 'https://api.adsensemedia.com/v1',
  mmwall: 'https://api.mmwall.com/v2',
  hangmyads: 'https://api.hangmyads.com/v1'
} as const;