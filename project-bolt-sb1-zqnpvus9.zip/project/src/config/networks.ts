import { CPANetwork } from '../types/cpa';
import { env } from './env';
import { networkUrls } from './networkUrls';

export const networks: CPANetwork[] = [
  {
    id: 'offertoro',
    name: 'OfferToro',
    apiKey: env.OFFERTORO_API_KEY,
    baseUrl: 'https://api.offertoro.com/api/v2',
  },
  {
    id: 'adgate',
    name: 'AdGate Media',
    apiKey: env.ADGATE_API_KEY,
    baseUrl: 'https://api.adgatemedia.com/v1',
  },
  {
    id: 'ayet',
    name: 'Ayetstudios',
    apiKey: env.AYET_API_KEY,
    baseUrl: 'https://api.ayetstudios.com/api/v1',
  },
  {
    id: 'mychips',
    name: 'MyChips',
    apiKey: env.MYCHIPS_API_KEY,
    baseUrl: networkUrls.mychips,
  },
  {
    id: 'revu',
    name: 'Revenue Universe',
    apiKey: env.REVU_API_KEY,
    baseUrl: networkUrls.revu,
  },
  {
    id: 'adgem',
    name: 'AdGem',
    apiKey: env.ADGEM_API_KEY,
    baseUrl: networkUrls.adgem,
  },
  {
    id: 'adsensemedia',
    name: 'AdSense Media',
    apiKey: env.ADSENSEMEDIA_API_KEY,
    baseUrl: networkUrls.adsensemedia,
  },
  {
    id: 'mmwall',
    name: 'MMWall',
    apiKey: env.MMWALL_API_KEY,
    baseUrl: networkUrls.mmwall,
  },
  {
    id: 'hangmyads',
    name: 'HangMyAds',
    apiKey: env.HANGMYADS_API_KEY,
    baseUrl: networkUrls.hangmyads,
  },
];