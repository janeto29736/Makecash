import React from 'react';
import { ExternalLink, Clock, Trophy } from 'lucide-react';
import type { Offer } from '../types';

interface OfferCardProps {
  offer: Offer;
}

export default function OfferCard({ offer }: OfferCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative">
        <img 
          src={offer.imageUrl} 
          alt={offer.title}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-2 right-2 bg-indigo-600 text-white px-3 py-1 rounded-full">
          ${offer.reward.toFixed(2)}
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-semibold">{offer.title}</h3>
          <span className={`px-2 py-1 rounded text-sm ${
            offer.difficulty === 'easy' ? 'bg-green-100 text-green-800' :
            offer.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-800' :
            'bg-red-100 text-red-800'
          }`}>
            {offer.difficulty}
          </span>
        </div>
        
        <p className="text-gray-600 text-sm mb-4">{offer.description}</p>
        
        <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
          <div className="flex items-center">
            <Clock className="w-4 h-4 mr-1" />
            {offer.timeEstimate}
          </div>
          <div className="flex items-center">
            <Trophy className="w-4 h-4 mr-1" />
            {offer.provider}
          </div>
        </div>
        
        <button className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition-colors flex items-center justify-center">
          <ExternalLink className="w-4 h-4 mr-2" />
          Start Offer
        </button>
      </div>
    </div>
  );
}