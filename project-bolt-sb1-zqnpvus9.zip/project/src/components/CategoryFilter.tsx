import React from 'react';
import { Layout, GamepadIcon, ClipboardList, BarChart3 } from 'lucide-react';

const categories = [
  { id: 'all', name: 'All Offers', icon: Layout },
  { id: 'surveys', name: 'Surveys', icon: ClipboardList },
  { id: 'games', name: 'Games', icon: GamepadIcon },
  { id: 'tasks', name: 'Tasks', icon: BarChart3 },
];

interface CategoryFilterProps {
  selected: string;
  onSelect: (category: string) => void;
}

export default function CategoryFilter({ selected, onSelect }: CategoryFilterProps) {
  return (
    <div className="flex space-x-4 mb-8 overflow-x-auto pb-2">
      {categories.map(({ id, name, icon: Icon }) => (
        <button
          key={id}
          onClick={() => onSelect(id)}
          className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
            selected === id
              ? 'bg-indigo-600 text-white'
              : 'bg-white text-gray-600 hover:bg-gray-50'
          }`}
        >
          <Icon className="w-5 h-5 mr-2" />
          {name}
        </button>
      ))}
    </div>
  );
}