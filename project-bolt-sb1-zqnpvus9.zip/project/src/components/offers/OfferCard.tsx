import React from 'react';
import { ExternalLink } from 'lucide-react';
import type { Offer } from '../../types';
import { formatCurrency } from '../../utils/formatCurrency';
import OfferDifficulty from './OfferDifficulty';
import OfferMetadata from './OfferMetadata';

interface OfferCardProps {
  offer: Offer;
}

export default function OfferCard({ offer }: OfferCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative">
        <img 
          src={offer.imageUrl} 
          alt={offer.title}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-2 right-2 bg-indigo-600 text-white px-3 py-1 rounded-full">
          {formatCurrency(offer.reward)}
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-semibold">{offer.title}</h3>
          <OfferDifficulty difficulty={offer.difficulty} />
        </div>
        
        <p className="text-gray-600 text-sm mb-4">{offer.description}</p>
        
        <OfferMetadata 
          timeEstimate={offer.timeEstimate}
          provider={offer.provider}
        />
        
        <button className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition-colors flex items-center justify-center">
          <ExternalLink className="w-4 h-4 mr-2" />
          Start Offer
        </button>
      </div>
    </div>
  );
}