import React, { useState } from 'react';
import { useCPAOffers } from '../../hooks/useCPAOffers';
import OfferCard from './OfferCard';
import OfferFilters from './OfferFilters';
import { networks } from '../../config/networks';
import { CPAOffer } from '../../types/cpa';

export default function OfferWall() {
  const [selectedNetwork, setSelectedNetwork] = useState(networks[0].id);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('reward');
  const { offers, loading, error } = useCPAOffers(selectedNetwork);

  const filteredOffers = React.useMemo(() => {
    let result = [...offers];
    
    if (searchQuery) {
      result = result.filter(offer => 
        offer.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        offer.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    result.sort((a, b) => {
      switch (sortBy) {
        case 'reward':
          return b.reward - a.reward;
        case 'time':
          return parseInt(a.timeEstimate) - parseInt(b.timeEstimate);
        case 'difficulty':
          const difficultyOrder = { easy: 0, medium: 1, hard: 2 };
          return difficultyOrder[a.difficulty] - difficultyOrder[b.difficulty];
        default:
          return 0;
      }
    });

    return result;
  }, [offers, searchQuery, sortBy]);

  if (error) {
    return (
      <div className="text-center py-8">
        <p className="text-red-600">Error loading offers: {error}</p>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <select
          value={selectedNetwork}
          onChange={(e) => setSelectedNetwork(e.target.value)}
          className="w-full md:w-64 px-4 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
        >
          {networks.map((network) => (
            <option key={network.id} value={network.id}>
              {network.name}
            </option>
          ))}
        </select>
      </div>

      <OfferFilters 
        onSearch={setSearchQuery}
        onSort={setSortBy}
      />

      {loading ? (
        <div className="text-center py-8">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-indigo-600 border-r-transparent"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredOffers.map((offer) => (
            <OfferCard key={`${offer.networkId}-${offer.id}`} offer={offer} />
          ))}
        </div>
      )}
    </div>
  );
}