import React from 'react';
import { Clock, Trophy } from 'lucide-react';

interface OfferMetadataProps {
  timeEstimate: string;
  provider: string;
}

export default function OfferMetadata({ timeEstimate, provider }: OfferMetadataProps) {
  return (
    <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
      <div className="flex items-center">
        <Clock className="w-4 h-4 mr-1" />
        {timeEstimate}
      </div>
      <div className="flex items-center">
        <Trophy className="w-4 h-4 mr-1" />
        {provider}
      </div>
    </div>
  );
}