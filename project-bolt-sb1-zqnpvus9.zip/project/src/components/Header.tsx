import React from 'react';
import { Wallet, Menu, Bell } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-indigo-600 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <span className="text-2xl font-bold">EarnWise</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center bg-indigo-700 px-4 py-2 rounded-lg">
              <Wallet className="w-5 h-5 mr-2" />
              <span className="font-semibold">$0.00</span>
            </div>
            
            <button className="p-2 rounded-full hover:bg-indigo-700">
              <Bell className="w-6 h-6" />
            </button>
            
            <button className="p-2 rounded-full hover:bg-indigo-700">
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}