import React from 'react';
import { Home, LayoutGrid, Trophy, Wallet, Settings } from 'lucide-react';

const navigation = [
  { name: 'Dashboard', icon: Home },
  { name: 'Offer Wall', icon: LayoutGrid },
  { name: 'Leaderboard', icon: Trophy },
  { name: 'Withdraw', icon: Wallet },
  { name: 'Settings', icon: Settings },
];

export default function Sidebar() {
  return (
    <aside className="w-64 bg-white border-r border-gray-200 min-h-screen p-4">
      <nav className="space-y-2">
        {navigation.map(({ name, icon: Icon }) => (
          <button
            key={name}
            className="flex items-center w-full px-4 py-2 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <Icon className="w-5 h-5 mr-3" />
            <span>{name}</span>
          </button>
        ))}
      </nav>
    </aside>
  );
}