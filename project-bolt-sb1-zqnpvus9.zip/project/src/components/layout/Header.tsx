import React, { useState } from 'react';
import { Wallet, Menu, Bell, LogOut } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { supabase } from '../../lib/supabase';
import AuthModal from '../auth/AuthModal';
import { formatCurrency } from '../../utils/formatCurrency';
import { useUser } from '../../hooks/useUser';

export default function Header() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const { user } = useAuth();
  const balance = useUser((state) => state.balance);

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  return (
    <>
      <header className="bg-indigo-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <span className="text-2xl font-bold">EarnWise</span>
            </div>
            
            <div className="flex items-center space-x-4">
              {user ? (
                <>
                  <div className="flex items-center bg-indigo-700 px-4 py-2 rounded-lg">
                    <Wallet className="w-5 h-5 mr-2" />
                    <span className="font-semibold">{formatCurrency(balance)}</span>
                  </div>
                  
                  <button className="p-2 rounded-full hover:bg-indigo-700">
                    <Bell className="w-6 h-6" />
                  </button>
                  
                  <button 
                    onClick={handleLogout}
                    className="p-2 rounded-full hover:bg-indigo-700"
                  >
                    <LogOut className="w-6 h-6" />
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setIsAuthModalOpen(true)}
                  className="bg-white text-indigo-600 px-4 py-2 rounded-lg hover:bg-indigo-50"
                >
                  Login
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </>
  );
}