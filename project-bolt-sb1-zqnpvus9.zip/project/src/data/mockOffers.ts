import { CPAOffer } from '../types/cpa';

// Add mock offers for new networks
const additionalMockOffers: CPAOffer[] = [
  {
    id: '3',
    networkId: 'mychips',
    campaignId: 'mobile-123',
    title: 'Mobile Game Challenge',
    description: 'Play and reach level 10 in our new mobile game',
    reward: 5.00,
    payout: 5.00,
    provider: 'MyChips Gaming',
    requirements: ['Android/iOS device', 'New users only'],
    imageUrl: 'https://images.unsplash.com/photo-1533226458520-6f71cffeaa6a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    category: 'games',
    difficulty: 'medium',
    timeEstimate: '20-30 min',
    trackingUrl: 'https://mychips.example.com/track',
    conversionPoints: 500,
    countries: ['ALL'],
    platform: 'mobile'
  },
  {
    id: '4',
    networkId: 'revu',
    campaignId: 'survey-789',
    title: 'Market Research Survey',
    description: 'Share your opinion about new products',
    reward: 2.50,
    payout: 2.50,
    provider: 'RevU Research',
    requirements: ['18+ years old'],
    imageUrl: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    category: 'surveys',
    difficulty: 'easy',
    timeEstimate: '15-20 min',
    trackingUrl: 'https://revu.example.com/track',
    conversionPoints: 250,
    countries: ['US', 'CA', 'UK'],
    platform: 'all'
  }
];

export const mockOffers: CPAOffer[] = [
  // ... existing mock offers ...
  ...additionalMockOffers
];