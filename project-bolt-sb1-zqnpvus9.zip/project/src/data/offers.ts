import { Offer } from '../types';

export const offers: Offer[] = [
  {
    id: '1',
    title: 'Complete Short Survey',
    description: 'Share your opinion about recent online shopping experiences',
    reward: 0.50,
    provider: 'SurveyJunkie',
    requirements: ['Valid email', '18+ years old'],
    imageUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    category: 'surveys',
    difficulty: 'easy',
    timeEstimate: '5-10 min'
  },
  {
    id: '2',
    title: 'Play Mobile Game',
    description: 'Reach level 10 in Kingdom Rush and earn rewards',
    reward: 2.00,
    provider: 'GameRewards',
    requirements: ['Android/iOS device', 'New users only'],
    imageUrl: 'https://images.unsplash.com/photo-1556438064-2d7646166914?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    category: 'games',
    difficulty: 'medium',
    timeEstimate: '30-45 min'
  },
  {
    id: '3',
    title: 'Website Testing',
    description: 'Review a new e-commerce website and provide feedback',
    reward: 3.00,
    provider: 'UserTesting',
    requirements: ['Desktop/Laptop', 'Microphone'],
    imageUrl: 'https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    category: 'tasks',
    difficulty: 'hard',
    timeEstimate: '20-25 min'
  }
];