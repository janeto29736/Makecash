export interface CPANetwork {
  id: string;
  name: string;
  apiKey: string;
  baseUrl: string;
}

export interface CPAOffer extends Offer {
  networkId: string;
  campaignId: string;
  payout: number;
  trackingUrl: string;
  conversionPoints: number;
  countries: string[];
  platform: 'desktop' | 'mobile' | 'all';
}

export interface CPAConversion {
  id: string;
  userId: string;
  offerId: string;
  networkId: string;
  status: 'pending' | 'completed' | 'rejected';
  amount: number;
  completedAt: string;
  updatedAt: string;
}