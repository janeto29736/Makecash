export interface Offer {
  id: string;
  title: string;
  description: string;
  reward: number;
  provider: string;
  requirements: string[];
  imageUrl: string;
  category: 'surveys' | 'tasks' | 'games' | 'apps';
  difficulty: 'easy' | 'medium' | 'hard';
  timeEstimate: string;
}

export interface User {
  id: string;
  email: string;
  balance: number;
  completedOffers: string[];
  created_at: string;
}