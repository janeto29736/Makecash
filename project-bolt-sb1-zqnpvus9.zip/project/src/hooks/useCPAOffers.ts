import { useState, useEffect } from 'react';
import { CPAOffer } from '../types/cpa';
import { cpaService } from '../services/cpaService';

export function useCPAOffers(networkId: string) {
  const [offers, setOffers] = useState<CPAOffer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchOffers = async () => {
      try {
        setLoading(true);
        const fetchedOffers = await cpaService.fetchOffers(networkId);
        setOffers(fetchedOffers);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch offers');
      } finally {
        setLoading(false);
      }
    };

    fetchOffers();
  }, [networkId]);

  return { offers, loading, error };
}