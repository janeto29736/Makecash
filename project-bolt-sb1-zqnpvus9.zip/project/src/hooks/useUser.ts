import { create } from 'zustand';

interface UserState {
  balance: number;
  completedOffers: string[];
  addCompletedOffer: (offerId: string, reward: number) => void;
}

export const useUser = create<UserState>((set) => ({
  balance: 0,
  completedOffers: [],
  addCompletedOffer: (offerId, reward) => 
    set((state) => ({
      balance: state.balance + reward,
      completedOffers: [...state.completedOffers, offerId]
    }))
}));