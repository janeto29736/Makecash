import React from 'react';
import Layout from './components/layout/Layout';
import OfferWall from './components/offers/OfferWall';
import { AuthProvider } from './contexts/AuthProvider';

function App() {
  return (
    <AuthProvider>
      <Layout>
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Earn Money Online</h1>
            <p className="mt-2 text-gray-600">Complete offers and surveys to earn real money</p>
          </div>
          <OfferWall />
        </div>
      </Layout>
    </AuthProvider>
  );
}

export default App;