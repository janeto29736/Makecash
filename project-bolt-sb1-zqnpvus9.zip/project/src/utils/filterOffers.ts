import { Offer } from '../types';

export const filterOffersByCategory = (offers: Offer[], category: string): Offer[] => {
  return category === 'all' ? offers : offers.filter(offer => offer.category === category);
};